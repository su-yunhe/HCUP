"""Task-owned loopback HTTP fixtures. Never forwards a request upstream.

Start only after the orchestrator's run authorization. All request bytes are
logged before responding, including failures and timed-out connections.
"""
from __future__ import annotations

import argparse
import base64
import json
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


def address(identifier=701, contact='本地默认甲', default=True):
    return dict(id=identifier, contact=contact, phone='13800000001', province='北京市',
                city='北京市', district='东城区', address=f'本地测试路{identifier}号', isDefault=default)


def success(data):
    return dict(code=1000, message=None, data=data)


class State:
    def __init__(self, logfile):
        self.logfile = Path(logfile)
        self.logfile.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.reset({})

    def reset(self, config):
        with self.lock:
            self.config = dict(scenario='with-address', mode='success', delay=2.0, confirm_fail_first=False,
                               confirm_delay=0.0, empty_addresses=False, no_coupon=False,
                               run_id=f'run-{time.time_ns()}')
            self.config.update(config)
            self.requests = []
            self.creates = 0
            self.confirms = 0
            self.addresses = [] if self.config['empty_addresses'] else (
                [address(), address(907, '本地选择乙', False)] if self.config['scenario'] == 'with-address'
                else [address(907, '本地选择乙', False)])
            self.next_address = 1201

    def emit(self, record):
        record = dict(utc=datetime.now(timezone.utc).isoformat(), **record)
        with self.lock, self.logfile.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + '\n')
            stream.flush()


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *args):
        pass

    @property
    def state(self):
        return self.server.state

    def respond(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self.dispatch()

    def do_POST(self):
        self.dispatch()

    def dispatch(self):
        path = self.path.split('?', 1)[0]
        size = int(self.headers.get('Content-Length', '0'))
        if size > 1024 * 1024:
            self.respond({'error': 'body too large'}, 413)
            return
        raw = self.rfile.read(size)
        try:
            body = json.loads(raw) if raw else None
        except ValueError:
            body = None
        if path == '/_control/reset' and self.command == 'POST':
            self.state.reset(body or {})
            self.state.emit({'kind': 'reset', 'config': self.state.config})
            self.respond({'run_id': self.state.config['run_id']})
            return
        if path == '/_control/state' and self.command == 'GET':
            with self.state.lock:
                self.respond({'config': self.state.config, 'requests': list(self.state.requests)})
            return
        with self.state.lock:
            cfg = dict(self.state.config)
            record = dict(kind='request', run_id=cfg['run_id'], sequence=len(self.state.requests) + 1,
                          monotonic=time.monotonic(), method=self.command, path=path,
                          raw_base64=base64.b64encode(raw).decode(), raw_utf8=raw.decode('utf-8', 'replace'),
                          body=body, authorization_present=bool(self.headers.get('Authorization')))
            self.state.requests.append(record)
            self.state.emit(record)
            if path == '/app/order/info/create' and self.command == 'POST':
                self.state.creates += 1
                create_number = self.state.creates
            else:
                create_number = 0
            if path == '/app/page/confirmOrder' and self.command == 'GET':
                self.state.confirms += 1
                confirm_number = self.state.confirms
            else:
                confirm_number = 0
        delay = 0.0
        status = 200
        if path == '/app/page/confirmOrder' and self.command == 'GET':
            coupon = dict(id=503, title='本地调查券503', amount=300, status=1, type=0,
                          condition={'fullAmount': 1000})
            payload = success({'defaultAddress': address() if cfg['scenario'] == 'with-address' else None,
                               'userCoupon': [] if cfg['no_coupon'] else [coupon]})
            delay = float(cfg['confirm_delay'])
            if cfg['confirm_fail_first'] and confirm_number == 1:
                payload = {'code': 1504, 'message': '本地受控确认页首次失败', 'data': None}
        elif path == '/app/user/address/page' and self.command == 'POST':
            with self.state.lock:
                payload = success({'list': list(self.state.addresses),
                                   'pagination': {'page': 1, 'size': 10, 'total': len(self.state.addresses)}})
        elif path == '/app/user/address/add' and self.command == 'POST':
            with self.state.lock:
                identifier = self.state.next_address
                self.state.next_address += 1
                self.state.addresses.append(dict(body or {}, id=identifier))
            payload = success({'id': identifier})
        elif create_number:
            mode = cfg['mode']
            if mode == 'failure-then-success':
                mode = 'business-failure' if create_number == 1 else 'success'
            order = {'id': 83016 + create_number, 'price': 99999, 'realPrice': 0 if mode == 'zero' else 4321}
            payload = success(order)
            if mode == 'business-failure':
                payload = {'code': 1501, 'message': '本地受控业务失败', 'data': None}
            elif mode == 'http-failure':
                status = 503
                payload = {'code': 1503, 'message': '本地受控HTTP失败', 'data': None}
            elif mode == 'null':
                payload = success(None)
            elif mode == 'missing-id':
                del order['id']
            elif mode == 'missing-price':
                del order['realPrice']
            elif mode == 'negative-price':
                order['realPrice'] = -1
            elif mode == 'slow':
                delay = float(cfg['delay'])
            elif mode == 'timeout':
                delay = 12.0
            elif mode not in ('success', 'zero'):
                payload, status = {'error': 'unknown fixture mode'}, 400
        else:
            payload, status = {'code': 1404, 'message': 'HCUP fixture rejects unknown request', 'data': None}, 404
        if delay:
            time.sleep(delay)
        response_record = dict(kind='response', run_id=cfg['run_id'], sequence=record['sequence'],
                               monotonic=time.monotonic(), status=status, payload=payload)
        try:
            self.respond(payload, status)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError) as error:
            response_record['connection_error'] = type(error).__name__
        self.state.emit(response_record)


def make_server(port, logfile):
    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.daemon_threads = True
    server.state = State(logfile)
    return server


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=18173)
    parser.add_argument('--log', type=Path, required=True)
    args = parser.parse_args()
    server = make_server(args.port, args.log)
    print(json.dumps({'host': '127.0.0.1', 'port': server.server_port,
                      'log': str(args.log), 'upstream_forwarding': False}), flush=True)
    server.serve_forever(poll_interval=0.2)


if __name__ == '__main__':
    main()
