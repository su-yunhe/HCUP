"""Create a NEW sandbox from an explicitly approved working-tree fingerprint.

No baseline archive, git checkout, recursive deletion or production writes.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import re
from pathlib import Path

ROOT = Path('D:/HCUP/cml-spec17')
OWN = ROOT / 'workflow/do-entry'
SANDBOX = ROOT / 'traces/do-01/build-root'
OUT = OWN / 'generated/do-01'
VARIANT = 'normal'
FAULT_FILES = {'core/database/src/main/ets/datasource/cart/CartLocalDataSourceImpl.ets',
               'core/datastore/src/main/ets/datasource/ordercache/OrderCacheStoreDataSourceImpl.ets'}
ADDED = {'DoFixture.ets': 'entry/src/main/ets/localtest/DoFixture.ets',
         'DoPage.ets': 'entry/src/main/ets/view/DoPage.ets',
         'DoProbe.ets': 'core/model/src/main/ets/localtest/DoProbe.ets'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def files(manifest):
    raw = json.loads(Path(manifest).read_text(encoding='utf-8-sig'))['files']
    return {r['path']: r['sha256'].lower() for r in raw} if isinstance(raw, list) else raw


def verify_source(expected):
    for name, digest in expected.items():
        path = ROOT / name
        if not path.resolve().is_relative_to(ROOT) or Path(name).is_absolute():
            raise RuntimeError(f'Unsafe production manifest path: {name}')
        if name.startswith(('traces/', 'workflow/', 'inputs/', 'logs/')):
            raise RuntimeError(f'Non-production path in production manifest: {name}')
        if sha(path.read_bytes()) != digest:
            raise RuntimeError(f'Production fingerprint changed: {name}')


def ability(text):
    text = text.replace('\r\n', '\n')
    prefix = "import { DoFixture } from '../localtest/DoFixture';\n"
    marker = '  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {\n'
    if text.count(marker) != 1:
        raise RuntimeError('EntryAbility onCreate anchor changed')
    extra = '''    const scenario = want.parameters?.hcupDoScenario;
    if (typeof scenario === 'string' && (scenario === 'with-address' || scenario === 'no-address')) {
      const entry = want.parameters?.hcupDoEntry === 'cart' ? 'cart' : 'confirm';
      const runId = want.parameters?.hcupDoRun;
      const fault = want.parameters?.hcupDoFault;
      DoFixture.configure(scenario, entry, want.parameters?.hcupDoAddressList === 'empty',
        want.parameters?.hcupDoPreserve === 'yes', typeof runId === 'string' ? runId : Date.now().toString(),
        typeof fault === 'string' ? fault : '', want.parameters?.hcupDoCache === 'empty');
    }
'''
    text = prefix + text.replace(marker, marker + extra)
    anchor = '    await this.initIBestORM();\n'
    if text.count(anchor) != 1:
        raise RuntimeError('EntryAbility ORM anchor changed')
    return text.replace(anchor, anchor + '''    if (DoFixture.isActive()) {
      await DoFixture.prepare();
      windowStage.loadContent('view/DoPage', (_) => {
        IBestUIInitializer.initIBestUI(windowStage, this.context);
        DoFixture.uiReady = true;
      });
      return;
    }
''')


def page(text):
    text = text.replace('\r\n', '\n')
    if '  aboutToAppear()' in text:
        raise RuntimeError('Page now has lifecycle hook; observation patch requires review')
    fields = ['remark', 'couponModalVisible', 'selectedCoupon', 'selectedAddress', 'data', 'cachedCarts', 'cartList',
              'selectedGoodsList', 'isFromCart', 'originalPrice', 'totalPrice']
    assignments = '\n'.join(f'      actual.{f} = this.vm.{f};' for f in fields)
    hook = ('  // Test-only reader. No assignments or business handler calls.\n'
            '  aboutToAppear(): void {\n'
            '    DoProbe.registerOrderReader((): DoOrderSnapshot => {\n'
            '      const actual = new DoOrderSnapshot();\n' + assignments + '\n'
            '      actual.uiState = String(this.vm.uiState);\n'
            '      return actual;\n    });\n  }\n\n')
    if text.count('  build() {') != 1:
        raise RuntimeError('OrderConfirmPage build anchor changed')
    return 'import { DoProbe, DoOrderSnapshot } from "model";\n' + text.replace('  build() {', hook + '  build() {')


def transform(name, text):
    if name == 'AppScope/app.json5':
        return text.replace('com.joker.coolmall', 'com.hcup.cmlspec17.localdo')
    if name == 'entry/src/main/ets/entryability/EntryAbility.ets':
        return ability(text)
    if name == 'feature/order/src/main/ets/view/OrderConfirmPage.ets':
        return page(text)
    if name == 'core/model/Index.ets':
        return text + '\nexport { DoProbe, DoOrderSnapshot, DoFaultBoundary } from "./src/main/ets/localtest/DoProbe";\n'
    if name == 'entry/oh-package.json5':
        return text.replace('"dependencies": {', '"dependencies": {\n    "data": "file:../core/data",\n'
                            '    "model": "file:../core/model",\n    "network": "file:../core/network",')
    if name == 'entry/src/main/resources/base/profile/main_pages.json':
        return text.replace('"view/EntryPage"', '"view/EntryPage",\n    "view/DoPage"')
    if VARIANT == 'fault' and name in FAULT_FILES:
        text = 'import { DoFaultBoundary } from "model";\n' + text.replace('\r\n', '\n')
        anchors = {'  async removeFromCart(goodsId: number): Promise<void> {\n': '    await DoFaultBoundary.beforeDelete(goodsId);\n',
                   '  async removeSpecFromCart(goodsId: number, specId: number): Promise<void> {\n': '    await DoFaultBoundary.beforeDelete(goodsId);\n'} if 'CartLocalDataSource' in name else {
                   '  async getCarts(): Promise<Cart[] | null> {\n': '    await DoFaultBoundary.beforeCacheRead();\n'}
        for anchor, injection in anchors.items():
            if text.count(anchor) != 1:
                raise RuntimeError(f'Fault-boundary anchor changed: {name}: {anchor}')
            text = text.replace(anchor, anchor + injection)
        return text
    return text


PATCHED = {'AppScope/app.json5', 'entry/src/main/ets/entryability/EntryAbility.ets',
           'feature/order/src/main/ets/view/OrderConfirmPage.ets', 'core/model/Index.ets',
           'entry/oh-package.json5', 'entry/src/main/resources/base/profile/main_pages.json'}


def audit(expected):
    verify_source(expected)
    changes, patch = [], []
    for name, digest in expected.items():
        before, after = (ROOT / name).read_bytes(), (SANDBOX / name).read_bytes()
        if before != after:
            generated = name.endswith('BuildProfile.ets') or name.endswith('oh-package-lock.json5')
            permitted = PATCHED | (FAULT_FILES if VARIANT == 'fault' else set())
            if name not in permitted and not generated:
                raise RuntimeError(f'Protected production bytes differ in sandbox: {name}')
            changes.append({'path': name, 'production_sha256': digest, 'sandbox_sha256': sha(after),
                            'kind': 'build-generated' if generated else 'test-boundary'})
            patch.extend(difflib.unified_diff(before.decode('utf-8').splitlines(True),
                                             after.decode('utf-8').splitlines(True),
                                             fromfile='PRODUCTION/' + name, tofile='DO_SANDBOX/' + name))
    save('sandbox-changes.json', changes)
    (OUT / 'sandbox.patch').write_text(''.join(patch), encoding='utf-8')
    save('protected-byte-check.json', {'checked': len(expected), 'variant': VARIANT,
                                     'test_patched': sorted(PATCHED | (FAULT_FILES if VARIANT == 'fault' else set())),
                                     'all_other_production_files_byte_identical': True})
    added_manifest = OUT / 'added-template-fingerprint.json'
    if added_manifest.exists():
        for name, digest in json.loads(added_manifest.read_text()).items():
            if sha((SANDBOX / name).read_bytes()) != digest:
                raise RuntimeError(f'Test template changed after final copy: {name}')


def main():
    global SANDBOX, OUT, VARIANT
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['prepare', 'audit'])
    parser.add_argument('--fingerprint', type=Path, required=True)
    parser.add_argument('--authorized-final-copy', action='store_true')
    parser.add_argument('--round', default='do-01')
    parser.add_argument('--variant', choices=['normal', 'fault'], default='normal')
    args = parser.parse_args()
    if not re.fullmatch(r'do-\d{2}', args.round):
        raise RuntimeError('Round must be an explicit do-NN name')
    VARIANT = args.variant
    round_name = args.round + ('-fault' if VARIANT == 'fault' else '')
    SANDBOX = ROOT / 'traces' / round_name / 'build-root'
    OUT = OWN / 'generated' / round_name
    if Path.cwd().resolve() != ROOT or not SANDBOX.resolve().is_relative_to(ROOT / 'traces'):
        raise RuntimeError('Run only in the task root with the owned sandbox')
    expected = files(args.fingerprint)
    verify_source(expected)
    if args.mode == 'prepare':
        if not args.authorized_final_copy:
            raise RuntimeError('Final production-copy authorization has not been supplied')
        if SANDBOX.exists():
            raise RuntimeError('Refusing to overwrite any existing sandbox')
        if not PATCHED.issubset(expected):
            raise RuntimeError('Incomplete production manifest')
        SANDBOX.mkdir(parents=True)
        for name in expected:
            target = SANDBOX / name
            target.parent.mkdir(parents=True, exist_ok=True)
            content = (ROOT / name).read_bytes()
            if name in PATCHED or (VARIANT == 'fault' and name in FAULT_FILES):
                result = transform(name, content.decode('utf-8'))
                if result.encode() == content:
                    raise RuntimeError(f'Test-boundary anchor made no change: {name}')
                content = result.encode('utf-8')
            target.write_bytes(content)
        for filename, destination in ADDED.items():
            target = SANDBOX / destination
            target.parent.mkdir(parents=True, exist_ok=True)
            content = (OWN / 'templates' / filename).read_bytes()
            if filename == 'DoProbe.ets' and VARIANT == 'fault':
                content = content.replace(b'static installed: boolean = false;', b'static installed: boolean = true;')
            target.write_bytes(content)
        if (ROOT / 'local.properties').exists():
            (SANDBOX / 'local.properties').write_bytes((ROOT / 'local.properties').read_bytes())
        save('production-fingerprint.json', json.loads(args.fingerprint.read_text(encoding='utf-8-sig')))
        save('added-template-fingerprint.json', {p: sha((SANDBOX / p).read_bytes()) for p in ADDED.values()})
    audit(expected)
    print(json.dumps({'mode': args.mode, 'source_count': len(expected), 'sandbox': str(SANDBOX)}))


if __name__ == '__main__':
    main()
