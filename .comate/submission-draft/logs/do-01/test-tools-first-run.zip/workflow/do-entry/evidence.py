"""Read ONLY actual test-bundle diagnostics; no expected business calculations."""
from __future__ import annotations

import json


def states_from_hilog(raw, run_id):
    groups = {}
    for line in raw.splitlines():
        if '[HCUP_DO] CHUNK ' not in line:
            continue
        chunk = json.loads(line.split('[HCUP_DO] CHUNK ', 1)[1])
        if chunk['runId'] != run_id:
            continue
        key = chunk['snapshotId'], chunk['kind']
        item = groups.setdefault(key, {'total': chunk['total'], 'parts': {}})
        index = chunk['index']
        if item['total'] != chunk['total'] or not 0 <= index < item['total']:
            raise ValueError('Inconsistent diagnostic chunk metadata')
        if index in item['parts'] and item['parts'][index] != chunk['payload']:
            raise ValueError('Conflicting diagnostic chunk')
        item['parts'][index] = chunk['payload']
    records, incomplete = {}, []
    for key, item in groups.items():
        if set(item['parts']) != set(range(item['total'])):
            incomplete.append({'snapshotId': key[0], 'kind': key[1]})
            continue
        payload = ''.join(item['parts'][n] for n in range(item['total']))
        records[key] = json.loads(payload) if key[1] in ('STATE', 'ORDER_ACTUAL', 'CARTS_ACTUAL') else payload
    result = []
    for (snapshot_id, kind), state in records.items():
        if kind != 'STATE' or not snapshot_id.startswith('snapshot-'):
            continue
        if not all((snapshot_id, k) in records for k in ('ORDER_ACTUAL', 'CARTS_ACTUAL', 'COUNTS')):
            continue
        if state['order'] != records[(snapshot_id, 'ORDER_ACTUAL')] or state['carts'] != records[(snapshot_id, 'CARTS_ACTUAL')]:
            raise ValueError('Conflicting actual-object diagnostic records')
        result.append((int(snapshot_id.split('-')[-1]), state))
    return [state for _, state in sorted(result)], incomplete
