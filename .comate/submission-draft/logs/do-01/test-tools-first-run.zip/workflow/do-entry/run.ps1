param([string]$Round = 'do-01', [ValidateSet('normal','fault')][string]$Variant = 'normal', [switch]$AuthorizedDeviceWindow)
$ErrorActionPreference = 'Stop'
. 'D:/HCUP/.hcup-local/Enter-HarmonyEnv.ps1'
if (-not $AuthorizedDeviceWindow) { throw 'An explicit orchestrator device window is required' }
if ($Round -notmatch '^do-\d{2}$') { throw 'Invalid task round' }
$taskRoot = 'D:/HCUP/cml-spec17'
$roundName = $Round
if ($Variant -eq 'fault') { $roundName += '-fault' }
$toolRoot = Join-Path $taskRoot 'workflow/do-entry'
$outRoot = Join-Path $taskRoot "logs/$roundName"
$hapInfoPath = Join-Path $toolRoot "generated/$roundName/hap.json"
$manifest = Join-Path $toolRoot "generated/$roundName/production-fingerprint.json"
$hapInfo = Get-Content -LiteralPath $hapInfoPath -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $hapInfo.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hapInfo.sha256) { throw 'HAP changed' }
Set-Location -LiteralPath $taskRoot
& python -B (Join-Path $toolRoot 'prepare.py') audit --fingerprint $manifest --round $Round --variant $Variant
if ($LASTEXITCODE -ne 0) { throw 'Source drift before test' }
$occupied = Get-NetTCPConnection -LocalPort 18173 -State Listen -ErrorAction SilentlyContinue
if ($occupied) { throw 'Task loopback port already occupied; coordinate instead of stopping another process' }
New-Item -ItemType Directory -Path $outRoot -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$pythonPath = (Get-Command python).Source
$serverArgs = @('-B', (Join-Path $toolRoot 'server.py'), '--port', '18173', '--log', (Join-Path $outRoot "http-$stamp.jsonl"))
$server = Start-Process -FilePath $pythonPath -ArgumentList $serverArgs -WindowStyle Hidden -PassThru -WorkingDirectory $taskRoot -RedirectStandardOutput (Join-Path $outRoot "server-$stamp.log") -RedirectStandardError (Join-Path $outRoot "server-$stamp-error.log")
$server.Id | Set-Content -LiteralPath (Join-Path $outRoot "server-$stamp-pid.txt")
try {
  $deadline = (Get-Date).AddSeconds(10)
  do {
    if ($server.HasExited) { throw 'Fixture server failed to start' }
    try { $health = Invoke-RestMethod -Uri 'http://127.0.0.1:18173/_control/state' -TimeoutSec 1; break } catch { Start-Sleep -Milliseconds 200 }
  } while ((Get-Date) -lt $deadline)
  if (-not $health) { throw 'Fixture server health check failed' }
  & hdc -t 127.0.0.1:11243 fport ls *> (Join-Path $outRoot "forward-list-$stamp.log")
  $forwardList = Get-Content -LiteralPath (Join-Path $outRoot "forward-list-$stamp.log") -Raw
  $knownRoute = @($forwardList -split "`n" | Where-Object { $_ -match '127\.0\.0\.1:11243' -and $_ -match 'tcp:18173\s+tcp:18173' -and $_ -match '(?i)reverse' })
  if ($knownRoute.Count -gt 0) {
    'Reusing previously logged exact task-owned 11243 reverse route on port18173' | Set-Content -LiteralPath (Join-Path $outRoot "rport-$stamp.log")
  } else {
    & hdc -t 127.0.0.1:11243 rport tcp:18173 tcp:18173 *> (Join-Path $outRoot "rport-$stamp.log")
    $portExit = $LASTEXITCODE
    $portText = Get-Content -LiteralPath (Join-Path $outRoot "rport-$stamp.log") -Raw
    if ($portExit -ne 0 -or $portText -match '\[Fail\]') { throw 'Reverse port setup failed; no tests run' }
  }
  & hdc -t 127.0.0.1:11243 install -r $hapInfo.path *> (Join-Path $outRoot "install-$stamp.log")
  $installExit = $LASTEXITCODE
  $installExit | Set-Content -LiteralPath (Join-Path $outRoot "install-$stamp-exit.txt")
  if ($installExit -ne 0 -or (Get-Content -LiteralPath (Join-Path $outRoot "install-$stamp.log") -Raw) -match '\[Fail\]') { throw 'Installation failed; no tests run' }
  & hdc -t 127.0.0.1:11243 shell bm dump -n com.hcup.cmlspec17.localdo *> (Join-Path $outRoot "bundle-$stamp.txt")
  $env:HCUP_DO_RUN_AUTHORIZED = '1'
  $env:HCUP_DO_VARIANT = $Variant
  $env:HCUP_DO_ROUND = $roundName
  $env:PYTHONDONTWRITEBYTECODE = '1'
  $jsonPath = Join-Path $outRoot "selftest-$stamp.json"
  Set-Location -LiteralPath $outRoot
  & $pythonPath -B -m harness.runner --project $taskRoot --device 127.0.0.1:11243 --json $jsonPath *> (Join-Path $outRoot "selftest-$stamp.log")
  $testExit = $LASTEXITCODE
  $testExit | Set-Content -LiteralPath (Join-Path $outRoot "selftest-$stamp-exit.txt")
  Set-Location -LiteralPath $taskRoot
  & python -B (Join-Path $toolRoot 'prepare.py') audit --fingerprint $manifest --round $Round --variant $Variant
  if ($LASTEXITCODE -ne 0) { throw 'Source drift invalidates test evidence' }
  $report = Get-Content -LiteralPath $jsonPath -Raw | ConvertFrom-Json
  if ($report.cases.Count -eq 0) { throw 'Zero discovered tests is not a pass' }
  if ($testExit -ne 0) { throw "Device tests failed: $testExit" }
  $skipped = @($report.cases | Where-Object { $_.outcome -eq 'skip' })
  if ($skipped.Count -gt 0) { Write-Output "$($skipped.Count) cases not verified in this variant; inspect JSON, do not count as pass" }
} finally {
  Set-Location -LiteralPath $taskRoot
  $env:HCUP_DO_RUN_AUTHORIZED = '0'
  if (-not $server.HasExited) { Stop-Process -Id $server.Id }
}
