# cml-spec17 实施版本独立测试

这里的脚手架与旧 `workflow/local-entry` 冻结证据分开。本题唯一目标设备为 `127.0.0.1:11243`；新包 `com.hcup.cmlspec17.localdo`，HTTP服务只监听host loopback18173。生产业务源码从主 Agent最终完整指纹按工作树字节复制，不从旧HEAD归档生成。

当前仅脚手架。未复制最终沙箱、未构建、未安装、未启动应用。每次PowerShell均先加载 `D:/HCUP/.hcup-local/Enter-HarmonyEnv.ps1`。`scaffold_check.py` 仅做本机临时HTTP端口/解析器工具检查，无hdc、UiDriver、应用或业务通过结论。

最终交接后才可从本题根执行：

```powershell
. D:/HCUP/.hcup-local/Enter-HarmonyEnv.ps1
python -B workflow/do-entry/prepare.py prepare --fingerprint workflow/do-implementation-fingerprint-01.json --authorized-final-copy
workflow/do-entry/build.ps1 -InstallDependencies
```

`--round do-01` 可显式改为后续do-02等新轮次；`--variant fault` 生成独立 `traces/do-01-fault/build-root`。各轮manifest/HAP记录在 `workflow/do-entry/generated/<round[-fault]>/`。`build.ps1 -Round do-01 -Variant fault`与对应轮次参数一致，所有旧轮次拒绝覆盖或删除。原方案允许的fault边界分别在原CartLocalDataSourceImpl删除和OrderCacheStoreDataSourceImpl读取之前加透明延迟/异常；故障后仍执行原持久化代码。正常变体保留两个原datasource字节。

`prepare` 拒绝覆盖任何已有沙箱；`audit` 检查生产清单及沙箱业务文件逐字节相同，正常测试差异只限app标识、启动入口、原确认页只读getter、model测试导出、entry测试依赖及页面注册；fault边界单独列明，所有VM/repo/业务handler仍字节相同。构建生成锁文件/BuildProfile变化单独登记。原 `NetworkClient` 字节相同，只在测试Want启用时设置其实例defaults.baseURL，保留原Axios HTTP adapter。`INTERNET`沿用原配置；原guard源码字节不改，在测试包显式Want下仅运行期移除指定受保护测试路由。缺测试Want保留普通认证行为。

`server.py --log logs/do-01/http.jsonl` 启动后，使用 `hdc -t 127.0.0.1:11243 rport tcp:18173 tcp:18173` 将设备loopback18173连到host18173；该命令格式来自本机hdc帮助，实际连通性仍需后续运行验证并记日志，不把host smoke当设备连通。`run.ps1 -AuthorizedDeviceWindow`统一记录启动server/forward/install/runner/audit，每次运行安装刚构建HAP。服务 `/_control/reset` 配置本次run，`/_control/state`读取原始请求；app白名单为确认页GET、地址列表/新增及订单create，其余404，无远端回落。code1000/data均为受控响应，不能宣称线上认证订单已创建。

测试启动Want：`hcupDoScenario=with-address|no-address`，`hcupDoEntry=confirm|cart`，`hcupDoRun=<独立run_id>`，`hcupDoPreserve=yes`禁重播种，`hcupDoAddressList=empty`供空地址链路。confirm为直购形状缓存种子，cart必须沿原Tab勾选和结算。持久性测试冷启动必须使用Preserve，不能重新种子掩盖数据库结果。

每次测试执行前安装当轮刚构建HAP并记录SHA256/updateTime/PID。在主 Agent确认源冻结、设备独占后才设置 `HCUP_DO_RUN_AUTHORIZED=1` 并从本题 `logs/do-01` 运行公共 `harness.runner --project D:/HCUP/cml-spec17 --device 127.0.0.1:11243 --json ...`。运行器的skip/零用例退出0不算通过；需另核用例名单、数量和每条E/D证据。

自动诊断读实际当前确认页VM、真实NavPathStack支付参数、真实CartRepository与订单缓存，不写业务状态；runId与严格分片保证不复用旧进程。支付页标题本身不能证明参数。已写地址新增、取消、同数异集合、DB延迟/故障、GET/cached readiness与成功receipt复用用例；全部尚未设备运行，均记not_run。过期集合由明确测试banner按钮改变合成DB，不调用清理helper替代原提交。Toast位置需查看短时实际截图/窗口读数，不能仅靠文字用例通过即标E18通过。
