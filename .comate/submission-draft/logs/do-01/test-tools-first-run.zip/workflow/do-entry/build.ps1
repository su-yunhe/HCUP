param([switch]$InstallDependencies, [string]$Round = 'do-01', [ValidateSet('normal','fault')][string]$Variant = 'normal')
$ErrorActionPreference = 'Stop'
. 'D:/HCUP/.hcup-local/Enter-HarmonyEnv.ps1'
$taskRoot = 'D:/HCUP/cml-spec17'
if ($Round -notmatch '^do-\d{2}$') { throw 'Invalid owned round name' }
$roundName = $Round
if ($Variant -eq 'fault') { $roundName += '-fault' }
$testRoot = Join-Path $taskRoot "traces/$roundName/build-root"
$toolRoot = Join-Path $taskRoot 'workflow/do-entry'
$manifest = Join-Path $toolRoot "generated/$roundName/production-fingerprint.json"
if (-not (Test-Path -LiteralPath $manifest)) { throw 'No authorized final production copy exists' }
if ((Resolve-Path -LiteralPath $testRoot).Path -ne $testRoot.Replace('/', '\')) { throw 'Unexpected sandbox' }
$outRoot = Join-Path $taskRoot "logs/$roundName"
New-Item -ItemType Directory -Path $outRoot -Force | Out-Null
$attempt = Get-Date -Format 'yyyyMMdd-HHmmss'
Set-Location -LiteralPath $taskRoot
& python -B (Join-Path $toolRoot 'prepare.py') audit --fingerprint $manifest --round $Round --variant $Variant
if ($LASTEXITCODE -ne 0) { throw 'Pre-build source verification failed' }
try {
  Set-Location -LiteralPath $testRoot
  if ($InstallDependencies) {
    & ohpm install --all *> (Join-Path $outRoot "ohpm-$attempt.log")
    $dependencyExit = $LASTEXITCODE
    $dependencyExit | Set-Content -LiteralPath (Join-Path $outRoot "ohpm-$attempt-exit.txt")
    if ($dependencyExit -ne 0) { throw "Dependency installation failed: $dependencyExit" }
  }
  'hvigorw.bat --mode module -p module=entry@default -p product=default -p buildMode=debug assembleHap --no-daemon' |
    Set-Content -LiteralPath (Join-Path $outRoot "build-$attempt-command.txt")
  & hvigorw.bat --mode module -p module=entry@default -p product=default -p buildMode=debug assembleHap --no-daemon *> (Join-Path $outRoot "build-$attempt.log")
  $buildExit = $LASTEXITCODE
  $buildExit | Set-Content -LiteralPath (Join-Path $outRoot "build-$attempt-exit.txt")
} finally { Set-Location -LiteralPath $taskRoot }
& python -B (Join-Path $toolRoot 'prepare.py') audit --fingerprint $manifest --round $Round --variant $Variant
if ($LASTEXITCODE -ne 0) { throw 'Post-build source verification failed' }
if ($buildExit -ne 0) { exit $buildExit }
$hap = Join-Path $testRoot 'entry/build/default/outputs/default/entry-default-unsigned.hap'
[ordered]@{path=$hap; sha256=(Get-FileHash -LiteralPath $hap -Algorithm SHA256).Hash.ToLowerInvariant(); length=(Get-Item -LiteralPath $hap).Length} |
  ConvertTo-Json | Set-Content -LiteralPath (Join-Path $toolRoot "generated/$roundName/hap.json") -Encoding utf8
