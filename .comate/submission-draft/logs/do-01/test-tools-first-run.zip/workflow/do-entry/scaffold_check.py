"""Host-only fixture/collector checks; never connects to hdc or the app."""
import ast
import importlib.util
import json
import sys
import threading
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path('D:/HCUP/cml-spec17')


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / f'workflow/do-entry/{name}.py')
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    out = ROOT / 'logs/do-scaffold-01'
    out.mkdir(parents=True, exist_ok=True)
    scripts = list((ROOT / 'workflow/do-entry').glob('*.py')) + list((ROOT / 'hypium_tests').glob('*.py'))
    for path in scripts:
        ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
    server_module = load('server')
    server = server_module.make_server(0, out / 'http-smoke.jsonl')
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    def request(path, body=None):
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode()
        req = urllib.request.Request(f'http://127.0.0.1:{server.server_port}{path}', data=data,
                                     headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=3) as response:
                return response.status, json.load(response)
        except urllib.error.HTTPError as response:
            return response.code, json.load(response)

    checks = []
    try:
        for mode in ['success', 'zero', 'business-failure', 'http-failure', 'null',
                     'missing-id', 'missing-price', 'negative-price', 'failure-then-success']:
            request('/_control/reset', {'run_id': 'host-smoke-' + mode, 'mode': mode})
            original = {'data': {'remark': '三个中文   ', 'addressId': 907, 'goodsList': [], 'couponId': 503}}
            status, result = request('/app/order/info/create', original)
            _, state = request('/_control/state')
            assert len(state['requests']) == 1
            assert state['requests'][0]['body'] == original
            assert json.loads(state['requests'][0]['raw_utf8']) == original
            if mode == 'success':
                assert status == 200 and result['data'] == {'id': 83017, 'price': 99999, 'realPrice': 4321}
            elif mode == 'zero':
                assert result['data']['realPrice'] == 0
            elif mode in ['business-failure', 'failure-then-success']:
                assert result['code'] != 1000
            elif mode == 'http-failure':
                assert status == 503
            elif mode == 'null':
                assert result['data'] is None
            elif mode == 'missing-id':
                assert 'id' not in result['data']
            elif mode == 'missing-price':
                assert 'realPrice' not in result['data']
            elif mode == 'negative-price':
                assert result['data']['realPrice'] < 0
            if mode == 'failure-then-success':
                _, second = request('/app/order/info/create', original)
                assert second['data']['id'] == 83018
            checks.append(mode)
        status, _ = request('/app/unrecognized')
        assert status == 404
        checks.append('unknown-path-denied')
        collector = load('evidence')
        actual = {'reason': 'poll', 'order': None, 'carts': []}
        records = {'STATE': actual, 'ORDER_ACTUAL': None, 'CARTS_ACTUAL': [], 'COUNTS': 'all zero'}
        lines = []
        for kind, value in records.items():
            chunk = {'runId': 'smoke', 'snapshotId': 'snapshot-1', 'kind': kind,
                     'index': 0, 'total': 1, 'payload': json.dumps(value) if kind != 'COUNTS' else value}
            lines.append('[HCUP_DO] CHUNK ' + json.dumps(chunk))
        parsed, incomplete = collector.states_from_hilog('\n'.join(lines), 'smoke')
        assert parsed == [actual] and incomplete == []
        assert collector.states_from_hilog('\n'.join(lines), 'other-run')[0] == []
        corrupted = json.loads(lines[0].split('CHUNK ')[1])
        corrupted['payload'] = '{}'
        try:
            collector.states_from_hilog('\n'.join(lines + ['[HCUP_DO] CHUNK ' + json.dumps(corrupted)]), 'smoke')
        except ValueError:
            checks.append('conflicting-diagnostic-rejected')
        else:
            raise AssertionError('Collector accepted a conflicting duplicate')
        checks += ['complete-actual-snapshot', 'wrong-run-rejected']
        generator = load('prepare')
        synthetic_page = '  build() {\n  }\n'
        instrumented = generator.page(synthetic_page)
        assert 'actual.selectedAddress = this.vm.selectedAddress;' in instrumented
        assert 'this.vm.onSubmit' not in instrumented
        checks.append('reader-patch-does-not-invoke-submit')
        for source in generator.FAULT_FILES:
            synthetic = ('  async removeFromCart(goodsId: number): Promise<void> {\n  }\n'
                         '  async removeSpecFromCart(goodsId: number, specId: number): Promise<void> {\n  }\n') if 'CartLocalDataSource' in source else '  async getCarts(): Promise<Cart[] | null> {\n  }\n'
            generator.VARIANT = 'normal'
            assert generator.transform(source, synthetic) == synthetic
            generator.VARIANT = 'fault'
            assert 'DoFaultBoundary' in generator.transform(source, synthetic)
        checks.append('normal-datasource-byte-preservation-vs-explicit-fault-patch')
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
    result = {'scope': 'HOST_TOOLING_ONLY_NO_DEVICE_NO_APP', 'python_ast_files': len(scripts), 'checks': checks,
              'business_requirements_passed': [], 'exit_code': 0}
    (out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
