"""Supplementary diagnosis runner using the unmodified common recording classes."""
import argparse
import json
import sys
import unittest
from pathlib import Path

from harness import env_check
from harness.report import RecordingResult, RunReport
from harness.runner import _inject_device_sn, _collect_case_names

parser = argparse.ArgumentParser()
parser.add_argument('--project', required=True)
parser.add_argument('--device', required=True)
parser.add_argument('--json', required=True)
parser.add_argument('--tests', nargs='+', required=True)
args = parser.parse_args()
if Path(args.project).resolve() != Path('D:/HCUP/cml-spec17') or args.device != '127.0.0.1:11243':
    raise RuntimeError('Unexpected task or device')
sys.path.insert(0, args.project)
suite = unittest.defaultTestLoader.loadTestsFromNames(args.tests)
names = _collect_case_names(suite)
if not names:
    raise RuntimeError('No tests selected')
_inject_device_sn(suite, args.device)
result = unittest.TextTestRunner(verbosity=2, resultclass=RecordingResult).run(suite)
report = RunReport(project=args.project, device_sn=args.device,
                   env_warnings=env_check.check(args.device).warnings, cases=result.to_cases(names))
report.print_summary()
Path(args.json).write_text(report.to_json(), encoding='utf-8')
raise SystemExit(0 if report.failed == 0 and report.skipped == 0 else 1)
